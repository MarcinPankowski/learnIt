package com.workshops;

/**
 * Created by marcinpankowski on 27.08.16.
 */
public class EmployeeSolution2 {
    public static void main(String[] args) {

    }
}
